
#ifndef __MAIN_H_
#define __MAIN_H_

#include "AppClass.h"
#include <stdio.h>
#include <stdlib.h>

#include "GL\glew.h"
#include "GLFW\glfw3.h"

#include "GLM\glm.hpp"


#endif //__MAIN_H_

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/